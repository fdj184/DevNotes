﻿using System;

namespace HelloWorld
{
    public class Stopwatch
    {
        // Fields
        private DateTime _start;
        private DateTime _stop;
        private bool _isRunning;

        // Constructors

        // Properties

        // Methods
        public void Start()
        {
            if (_isRunning)
                throw new InvalidOperationException("You may not start the stopwatch in this time.");
            else
            {
                _start = DateTime.Now;
                _isRunning = true;
            }
        }

        public void Stop()
        {
            if (!_isRunning)
                throw new InvalidOperationException("You may not stop the stopwatch in this time.");
            else
            {
                _stop = DateTime.Now;
                _isRunning = false;
            }
        }

        public string Display()
        {
            if (_isRunning)
                throw new InvalidOperationException("The stopwatch is still running.");

            return (_stop - _start).TotalSeconds.ToString();
        }
    }
}
