﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    partial class Program
    {
        static void Main(string[] args)
        {
            var stopwatch = new Stopwatch();
            while (true)
            {
                try
                {
                    Console.WriteLine("enter a command");
                    var cmd = Console.ReadLine();
                    switch (cmd)
                    {
                        case "start":
                            stopwatch.Start();
                            break;
                        case "stop":
                            stopwatch.Stop();
                            break;
                        case "display":
                            Console.WriteLine(stopwatch.Display());
                            break;
                        default:
                            return;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }
        }
    }
}
