﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    partial class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("enter a command");
                    var cmd = Console.ReadLine();

                    // users must create a new post first
                    if (cmd != "new")
                    {
                        throw new InvalidOperationException("You must create a new post first.");
                    }

                    Console.WriteLine("enter a title");
                    var title = Console.ReadLine();

                    Console.WriteLine("enter a description");
                    var description = Console.ReadLine();

                    // create Post object
                    var post = new Post(title, description);

                    // ask commands for this post
                    var isDone = false;
                    while (!isDone)
                    {
                        Console.WriteLine("enter +1, -1, display or exit");
                        switch (Console.ReadLine())
                        {
                            case "+1":
                                post.UpVote();
                                break;
                            case "-1":
                                post.DownVote();
                                break;
                            case "display":
                                Console.WriteLine(post.Title);
                                Console.WriteLine(post.Description);
                                Console.WriteLine(post.CreatedDate);
                                Console.WriteLine(post.DisplayVoteValue());
                                break;
                            case "exit":
                                isDone = true;
                                break;
                            default:
                                continue;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
            }
        }
    }
}
