﻿using System;
using System.Collections.Generic;

namespace HelloWorld
{
    public class Post
    {
        // Fields

        // Constructors
        public Post(string title, string description)
        {
            Title = title;
            Description = description;
            CreatedDate = DateTime.Now;
        }

        // Properties
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime CreatedDate { get; private set; }
        public int VoteValue { get; private set; }


        // Methods
        public void UpVote()
        {
            VoteValue += 1;
        }

        public void DownVote()
        {
            VoteValue -= 1;
        }

        public int DisplayVoteValue()
        {
            return VoteValue;
        }
    }
}
