﻿namespace HelloWorld
{
    public interface IActivity
    {
        void Execute();
    }
}
