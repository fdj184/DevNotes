﻿using System;

namespace HelloWorld
{
    public class CallWebService  : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("I have a video ready for encoding.");
        }
    }
}
