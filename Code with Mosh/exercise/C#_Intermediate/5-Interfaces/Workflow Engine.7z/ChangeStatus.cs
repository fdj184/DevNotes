﻿using System;

namespace HelloWorld
{
    public class ChangeStatus  : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("Change the status in the database to \"Processing\"");
        }
    }
}
