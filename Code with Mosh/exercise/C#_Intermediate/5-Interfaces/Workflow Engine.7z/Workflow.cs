﻿using System.Collections.Generic;

namespace HelloWorld
{
    public class Workflow
    {
        private readonly IList<IActivity> _activities = new List<IActivity>();

        public void AddActivity(IActivity activity)
        {
            this._activities.Add(activity);
        }

        public void Run()
        {
            foreach (var activity in this._activities)
            {
                activity.Execute();
            }
        }
    }
}
