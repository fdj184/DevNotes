﻿using System;

namespace HelloWorld
{
    public class UploadVideo : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("Upload a video to a cloud storage.");
        }
    }
}
