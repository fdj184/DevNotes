﻿using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    partial class Program
    {
        static void Main(string[] args)
        {
            var workflow = new Workflow();
            workflow.AddActivity(new UploadVideo());
            workflow.AddActivity(new CallWebService());
            workflow.AddActivity(new Notification());
            workflow.AddActivity(new ChangeStatus());
            workflow.Run();
        }
    }
}
