﻿using System;

namespace HelloWorld
{
    public class Notification : IActivity
    {
        public void Execute()
        {
            Console.WriteLine("The video started processing.");
        }
    }
}
