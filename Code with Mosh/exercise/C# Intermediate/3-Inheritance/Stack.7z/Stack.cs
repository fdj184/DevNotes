﻿using System;
using System.Collections.Generic;

namespace HelloWorld
{
    public class Stack
    {
        // Fields
        private List<object> _list = new List<object>();

        // Properties
        public int Count
        {
            get
            {
                return _list.Count;
            }
        }

        // Methods
        public void Push(object obj)
        {
            if (obj == null)
                throw new InvalidOperationException("you may not store null references in the stack.");

            _list.Add(obj);
        }

        public object Pop()
        {
            var length = _list.Count;
            if (length == 0)
                throw new InvalidOperationException("the stack is empty.");

            var lastElement = _list[length - 1];
            _list.RemoveAt(length - 1);

            return lastElement;
        }

        public void Clear()
        {
            _list.Clear();
        }
    }
}
