﻿using System;

namespace HelloWorld
{
    public class DbCommand
    {
        // Constructor
        public DbCommand(DbConnection dbConnection, string instruction)
        {
            if (dbConnection == null)
                throw new InvalidOperationException("dbConnection should not be null.");
            else if (String.IsNullOrWhiteSpace(instruction))
                throw new InvalidOperationException("instruction should not be empty.");

            this.DbConnection = dbConnection;
            this.Instruction = instruction;
        }

        // Properties
        public DbConnection DbConnection { get; set; }
        public string Instruction { get; set; }

        // Methods
        public void Execute()
        {
            DbConnection.Open();
            Console.WriteLine(Instruction);
            DbConnection.Close();
        }
    }
}
