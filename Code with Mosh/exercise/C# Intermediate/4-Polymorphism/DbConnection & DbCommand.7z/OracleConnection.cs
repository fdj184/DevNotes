﻿using System;

namespace HelloWorld
{
    public class OracleConnection : DbConnection
    {
        public OracleConnection(string connectionString) : base(connectionString)
        {
        }

        public override void Open()
        {
            Console.WriteLine("OracleConnection opened.");
        }

        public override void Close()
        {
            Console.WriteLine("OracleConnection closed.");
        }
    }
}
