﻿using System;

namespace HelloWorld
{
    public abstract class DbConnection
    {
        // Constructor
        public DbConnection(string connectionString)
        {
            if (String.IsNullOrWhiteSpace(connectionString.Trim()))
                throw new InvalidOperationException("the connection string should not be empty.");

            this.ConnectionString = connectionString;
        }

        // Properties
        public string ConnectionString { get; set; }
        public TimeSpan Timeout { get; set; }

        // Methods
        public abstract void Open();
        public abstract void Close();
    }
}
