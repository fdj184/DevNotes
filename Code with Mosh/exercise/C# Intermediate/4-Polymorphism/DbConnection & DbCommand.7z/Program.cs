﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    partial class Program
    {
        static void Main(string[] args)
        {
            var instruction = "SELECT * FROM [Student]";
            var sqlConnection = new SqlConnection("Data Source=ABC;");
            var dbCommand = new DbCommand(sqlConnection, instruction);
            dbCommand.Execute();

            var oracleConnection = new OracleConnection("Data Source=DEF;");
            dbCommand = new DbCommand(oracleConnection, instruction);
            dbCommand.Execute();
        }
    }
}
